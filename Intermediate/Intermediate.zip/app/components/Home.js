// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


$scope.populateModelList = function() {

  $scope.app.params.modelSelect = [
  {
    display: "ATV Suspension_High",
    value: "app/resources/Uploaded/ATV Suspension_High.pvz"
  },
  {
    display: "ATV Suspension_Lov",
    value: "app/resources/Uploaded/ATV Suspension_Low.pvz"
  },
  {
    display: "ATV Suspension_Med",
    value: "app/resources/Uploaded/ATV Suspension_Med.pvz"
  }
  ];
  
}
 
$scope.populateModelList();